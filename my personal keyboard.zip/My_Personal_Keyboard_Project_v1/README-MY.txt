MY PERSONAL KEYBOARD — ပထမဆုံး Project

ပါဝင်သော အခြေခံများ
- Android Input Method Service (IME)
- Myanmar / English / Arabic / Urdu လက်ကွက် အခြေခံ
- Arabic Harakat ခလုတ်များ
- ဂဏန်းလက်ကွက်
- Emoji ခလုတ်
- Theme အလင်း/အမှောင် ပြောင်းခြင်း
- စာရိုက်သံ
- Speech Recognition ခေါ်သုံးရန် ခလုတ် (ဖုန်းတွင် Speech service ရှိရန်လိုပြီး Offline အာမမခံပါ)

သတိပြုရန်
ဤသည် ပထမဆုံး Prototype ဖြစ်သည်။ မြန်မာ Unicode လက်ကွက်၊ Urdu/Arabic အက္ခရာစုံလင်မှု၊ စာလုံးအကြံပြုစနစ်၊ Harakat placement နှင့် RTL rendering ကို စမ်းသပ်ပြီး ဆက်လက်ပြုပြင်ရန်လိုသည်။
ဤ project သည် Naskh အမည်ရှိ font file တစ်ခုကို မထည့်သွင်းထားသေးပါ။ စက်၏ fallback font ကို အသုံးပြုမည်။ တိကျသော Naskh font ကို နောက်အဆင့်တွင် license စစ်ဆေးပြီး ထည့်နိုင်သည်။

APK တည်ဆောက်ရန်
1. GitHub account ဖြင့် repository အသစ်တစ်ခု ဖန်တီးပါ။
2. ဤ ZIP ထဲရှိ ဖိုင်များအားလုံးကို repository ထဲသို့ upload လုပ်ပါ။
3. Actions tab ကိုဖွင့်ပါ။
4. "Build My Personal Keyboard APK" ကိုရွေးပါ။
5. Run workflow ကိုနှိပ်ပါ။
6. Build ပြီးပါက Artifacts ထဲမှ My-Personal-Keyboard-debug ကို download လုပ်ပါ။
7. ZIP ကိုဖြည်ပြီး app-debug.apk ကို install လုပ်ပါ။
8. Android Settings > System > Languages & input > On-screen keyboard > Manage keyboards ထဲတွင် My Personal Keyboard ကိုဖွင့်ပါ။
9. Text box တစ်ခုတွင် keyboard icon/input method picker မှ ရွေးပါ။

လိုအပ်ချက်
- GitHub account
- APK build လုပ်ချိန် Internet
- Android 6.0 နှင့်အထက်ကို ရည်ရွယ်ထားသည်။
