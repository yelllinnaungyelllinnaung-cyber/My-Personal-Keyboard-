package com.personal.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.media.AudioManager
import android.media.ToneGenerator

class MyKeyboardService : InputMethodService() {
    private enum class Lang { MY, EN, AR, UR }
    private var lang = Lang.MY
    private var numbers = false
    private var dark = false
    private var tone: ToneGenerator? = null
    private lateinit var root: LinearLayout
    private lateinit var keysArea: LinearLayout
    private lateinit var suggestions: LinearLayout

    override fun onCreate() {
        super.onCreate()
        tone = ToneGenerator(AudioManager.STREAM_SYSTEM, 45)
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 6, 5, 6)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(actionButton("🌐 ${langLabel()}") { cycleLanguage(); refreshKeys() }, weightParams(1f))
        top.addView(actionButton("123") { numbers = !numbers; refreshKeys() }, weightParams(0.7f))
        top.addView(actionButton("🎙") { launchVoiceInput() }, weightParams(0.7f))
        top.addView(actionButton("🎨") { dark = !dark; refreshKeys() }, weightParams(0.7f))
        top.addView(actionButton("⌄") { requestHideSelf(0) }, weightParams(0.7f))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(44)))

        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, dp(34)))
        keysArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysArea, LinearLayout.LayoutParams(-1, -2))
        refreshKeys()
        return root
    }

    private fun refreshKeys() {
        if (!::keysArea.isInitialized) return
        root.setBackgroundColor(if (dark) Color.rgb(32, 34, 38) else Color.rgb(232, 235, 240))
        keysArea.removeAllViews()
        suggestions.removeAllViews()
        listOf("စာလုံးအကြံပြု", "✨").forEach { /* suggestion area populated below */ }
        val sampleSuggestions = when (lang) {
            Lang.EN -> listOf("Hello", "Thanks", "Good")
            Lang.MY -> listOf("မင်္ဂလာ", "ကျေးဇူး", "ဟုတ်ကဲ့")
            Lang.AR -> listOf("مرحبا", "شكرا", "السلام")
            Lang.UR -> listOf("سلام", "شکریہ", "آپ")
        }
        sampleSuggestions.forEach { word ->
            suggestions.addView(actionButton(word) { commit(word) }, weightParams(1f))
        }

        val rows = when {
            numbers -> listOf(
                listOf("1","2","3","4","5","6","7","8","9","0"),
                listOf("@","#","$","%","&","-","+","(",")","/"),
                listOf("=", "*", "\"", "'", ":", ";", "!", "?", "⌫")
            )
            lang == Lang.EN -> listOf(
                listOf("q","w","e","r","t","y","u","i","o","p"),
                listOf("a","s","d","f","g","h","j","k","l"),
                listOf("⇧","z","x","c","v","b","n","m","⌫")
            )
            lang == Lang.MY -> listOf(
                listOf("ဆ","တ","န","မ","အ","ပ","က","င","သ","စ"),
                listOf("ျ","ိ","ီ","်","ွ","ု","ူ","ေ","ဲ"),
                listOf("⇧","ရ","လ","ဝ","ဟ","ယ","ါ","့","⌫")
            )
            lang == Lang.AR -> listOf(
                listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"),
                listOf("ش","س","ي","ب","ل","ا","ت","ن","م","ك"),
                listOf("⇧","ئ","ء","ؤ","ر","لا","ى","ة","⌫")
            )
            else -> listOf(
                listOf("ق","و","ع","ر","ت","ے","ء","ی","ہ","پ"),
                listOf("ا","س","د","ف","گ","ح","ج","ک","ل"),
                listOf("⇧","ز","ش","چ","ط","ب","ن","م","⌫")
            )
        }
        rows.forEach { row -> addKeyRow(row) }

        if (lang == Lang.AR) addSpecialRow(listOf("َ","ِ","ُ","ّ","ْ","ً","ٍ","ٌ","ٰ"))
        if (lang == Lang.UR) addSpecialRow(listOf("ء","آ","أ","ؤ","ئ","ۃ","ھ","ے"))

        val bottom = listOf("😊", ",", "🌐", "space", ".", "↵")
        addKeyRow(bottom)
    }

    private fun addKeyRow(labels: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        labels.forEach { label ->
            val shown = if (label == "space") "မြှား / Space" else label
            val btn = keyButton(shown) {
                when (label) {
                    "⌫" -> currentInputConnection?.deleteSurroundingText(1, 0)
                    "↵" -> sendEnter()
                    "🌐" -> { cycleLanguage(); refreshKeys() }
                    "😊" -> commit("😊")
                    "," -> commit(",")
                    "." -> commit(".")
                    "space" -> commit(" ")
                    "⇧" -> { /* Shift placeholder for first version */ }
                    else -> commit(label)
                }
            }
            row.addView(btn, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
        keysArea.addView(row, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun addSpecialRow(labels: List<String>) = addKeyRow(labels)

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 12f
        isAllCaps = false
        setTextColor(if (dark) Color.WHITE else Color.rgb(35, 40, 48))
        background = rounded(if (dark) Color.rgb(65, 69, 76) else Color.WHITE)
        setOnClickListener { action() }
        setPadding(dp(2), 0, dp(2), 0)
    }

    private fun keyButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = if (text.length > 3) 11f else 18f
        isAllCaps = false
        typeface = Typeface.DEFAULT
        setTextColor(if (dark) Color.WHITE else Color.rgb(30, 34, 40))
        background = rounded(if (dark) Color.rgb(70, 74, 82) else Color.WHITE)
        setOnClickListener {
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
            action()
        }
        setPadding(0, 0, 0, 0)
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(7).toFloat()
    }

    private fun weightParams(weight: Float) =
        LinearLayout.LayoutParams(0, dp(42), weight).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        }

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun cycleLanguage() {
        lang = when (lang) {
            Lang.MY -> Lang.EN
            Lang.EN -> Lang.AR
            Lang.AR -> Lang.UR
            Lang.UR -> Lang.MY
        }
        numbers = false
    }

    private fun langLabel() = when (lang) {
        Lang.MY -> "မြန်မာ"
        Lang.EN -> "EN"
        Lang.AR -> "عربي"
        Lang.UR -> "اردو"
    }

    private fun launchVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, when (lang) {
                    Lang.MY -> "my-MM"
                    Lang.EN -> "en-US"
                    Lang.AR -> "ar"
                    Lang.UR -> "ur"
                })
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            // Speech recognition app/service may not be installed.
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        tone?.release()
        tone = null
        super.onDestroy()
    }
}
